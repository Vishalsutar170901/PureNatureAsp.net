﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DispatchOrder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if(e.CommandName=="Dispatch")
        {
            int index = Convert.ToInt32(e.CommandArgument);
            string id = GridView1.Rows[index].Cells[0].Text;
            string strcmd = "update OrderParent set Status='Dispatched' where OrderID=" + id;
            SQLHelper.ExecuteNonQuery(strcmd);
            Response.Redirect("~/PrintBill.aspx?id="+ id);
        }
    }
}