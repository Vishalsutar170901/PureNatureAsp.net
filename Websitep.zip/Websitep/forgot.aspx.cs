﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class forgot : System.Web.UI.Page
{
    private string addinfo;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        string cs = ConfigurationManager.ConnectionStrings["MyCon"].ConnectionString;
        SqlConnection con = new SqlConnection(cs);
        con.Open();
        SqlCommand cmd = new SqlCommand("select SecAns from Users where UserName='" + txtUsername.Text + "'", con);
        cmd.ExecuteNonQuery();
        addinfo = cmd.ExecuteScalar().ToString();
        con.Close();
        if(addinfo ==txtSecque.Text)
        {
            Response.Redirect("http://localhost:53901/Homepage.aspx");

        }
        else
        {
            lblMsg.Text = "Incorrect....!!";
        }
    }
}