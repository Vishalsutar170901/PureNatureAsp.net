﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_CatMaster : System.Web.UI.Page
{
    public string strcmd { get; private set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            LoadCategory();
        }

    }
    private void LoadCategory()
    {
        try
        {
            string strcmd = "Select CatID,CatName from Categories order by CatID ";
            DataTable dt = new DataTable();
            dt = SQLHelper.FillData(strcmd);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.Message;
        }
    }
    private void Clears()
    {
      Hdf.Value = "";
        CategoryName.Text = "";
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
        CategoryName.Focus();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            string strcmd = "Select CatID from Categories where CatName='" + SQLHelper.sf(CategoryName.Text) + "'";
            DataTable dt = new DataTable();
            dt = SQLHelper.FillData(strcmd);
            if (dt.Rows.Count>0)
            {
                lblmsg.Text = "Categories Name is Already exist!!!";
                CategoryName.Focus();
            }
            else
            {
                strcmd = "insert into Categories(CatName)Values('" + CategoryName.Text + "')";
                SQLHelper.ExecuteNonQuery(strcmd);
                lblmsg.Text = "Categories Saved successfully";
                LoadCategory();
                Clears();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.Message;
        }
    }


    protected void btnClears_Click(object sender, EventArgs e)
    {
        Clears();
    }

    protected void GridView1_SelectedIndexChanged(object sender, GridViewCommandEventArgs e)
    {
        
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            string strcmd = "Select CatID from Categories where CatName='" + SQLHelper.sf(CategoryName.Text) + "'and CatID<>" + Hdf.Value;
            DataTable dt = new DataTable();
            dt = SQLHelper.FillData(strcmd);
            if (dt.Rows.Count>0)
            {
                lblmsg.Text = "Category name is Already exist!!!";
                CategoryName.Focus();
            }
            else
            {
                strcmd = "Update Categories set CatName='" + SQLHelper.sf(CategoryName.Text) + "' where CatID=" + Hdf.Value;
                SQLHelper.ExecuteNonQuery(strcmd);
                lblmsg.Text = "Category Updated successfully";
                LoadCategory();
                Clears();
            }
        }

        catch (Exception ex)
        {
            lblmsg.Text = ex.Message;
        }
    }


    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int index = 0;
        if (e.CommandName == "Ed")
        {
            index = Convert.ToInt32(e.CommandArgument);
            Hdf.Value = GridView1.Rows[index].Cells[0].Text;
            CategoryName.Text = GridView1.Rows[index].Cells[1].Text;
            btnSave.Enabled = false;
            btnUpdate.Enabled = true;
        }
        if (e.CommandName == "Del")
        {
            index = Convert.ToInt32(e.CommandArgument);
            string strID = GridView1.Rows[index].Cells[0].Text;
            try
            {
                string strcmd = "delete from Categories where CatID=" + strID;
                SQLHelper.ExecuteNonQuery(strcmd);
                lblmsg.Text = "CategoryName Deleted successfully";
                LoadCategory();
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }
    }
}

