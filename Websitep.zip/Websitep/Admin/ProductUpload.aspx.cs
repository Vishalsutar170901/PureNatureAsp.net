﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            LoadCategory();
        }
    }
    private void LoadCategory()
    {
        try
        {
            string strcdm = " Select CatID,CatName from Categories order by CatID";
            DataTable dt = new DataTable();
            dt = SQLHelper.FillData(strcdm);
            ddlCategory.DataSource = dt;
            ddlCategory.DataValueField = "CatID";
            ddlCategory.DataTextField = "CatName";
            ddlCategory.DataBind();



        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }

    protected void BtnUpload_Click(object sender, EventArgs e)
    {

        try
        {
            if (FileUpload1.HasFile)
            {
                string Ext = Path.GetExtension(FileUpload1.FileName);
                string[] strExt = { ".jpg", ".jpeg", ".Png", ".bmp" };
                if (strExt.Contains(Ext.ToLower()))
                {
                    string strPath = Server.MapPath("~//Fruits//");
                    string subDir = Guid.NewGuid().ToString();
                    Directory.CreateDirectory(strPath + subDir);
                    string strFilePath = "~/Fruits/" + subDir + "/" + FileUpload1.FileName;
                    FileUpload1.SaveAs(strPath + "/" + subDir + "/" + FileUpload1.FileName);
                    string strcmd = "Insert into Products(CatID,ProductName,Price,Pic) values(" +
                        ddlCategory.SelectedValue + ",'"+
                        SQLHelper.sf(txtName.Text) + "',"+txtprice.Text + ",'"+strFilePath +"')";
                    SQLHelper.ExecuteNonQuery(strcmd);
                    txtName.Text = "";
                    txtprice.Text = "";
                    lblMsg.Text = "Uploaded successfully";

                }
                else
                {
                    lblMsg.Text = "Upload only Image File";
                }

            }
            else
            {
                lblMsg.Text = "Upload Image File";
            }

        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
