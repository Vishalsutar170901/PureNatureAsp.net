﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Order : System.Web.UI.Page
{
    private string strcmd;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Dispatch")
        {
            int index = Convert.ToInt32(e.CommandArgument);
            string id = GridView1.Rows[index].Cells[0].Text;
            string strcmd = "update OrderParent set Status='Dispatched' where OrderID=" + id;
            SQLHelper.ExecuteNonQuery(strcmd);
          Response.Redirect("~/Admin/PrintBill.aspx?id=" + id);
            ///  Response.Redirect("~/PrintBill.aspx?id=" + id);
        }

        if (e.CommandName =="Reject")
        {
            string id = "";
            int index = 0;
            if(e.CommandName == "Reject")
            {
                index = Convert.ToInt32(e.CommandArgument);
                id = GridView1.Rows[index].Cells[0].Text;
                strcmd = "delete from OrderParent where OrderID=" + id;
                SQLHelper.ExecuteNonQuery(strcmd);
                Response.Redirect("~/Admin/cancelorder.aspx?id=" + id);
            }
        }
    }
}