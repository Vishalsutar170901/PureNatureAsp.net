﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class MyCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            LoadCart();
        }
    }
    private void LoadCart()
    {
        try
        {
            string strcmd = "select Cart.ProductID,Products.ProductName,Products.Pic,Products.Price,sum(Cart.Qty) as Qty, "+
                            " (Products.Price * sum(Cart.Qty)) as Amount from Products inner join Cart " +
                            "  on Products.ProductID = Cart.ProductID " +
                            "  where UserID ="+ Session["UserID"].ToString() +
                            " group by Cart.ProductID,Products.ProductName,Products.Pic,Products.Price,Cart.Qty,(Products.Price * Cart.Qty)";
            DataTable dt = new DataTable();
            dt = SQLHelper.FillData(strcmd);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            float Total = 0.0F;
            for(int i=0;i<dt.Rows.Count;i++)
            {
                Total += Convert.ToSingle(dt.Rows[i]["Amount"].ToString());
            }
            lblTotalAmount.Text = Total.ToString("#,###.00");
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            string id = Guid.NewGuid().ToString();
            string strcmd = "insert into OrderParent(CustName,CustAddress,Dated,id,Status,UserID) values('" +
                txtName.Text + "','" + txtAddress.Text + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "','" +
                id + "','Pending'," + Session["UserID"].ToString() + ")";
            SQLHelper.ExecuteNonQuery(strcmd);

            strcmd = "select ProductID,Price,Qty from Cart where UserID=" + Session["UserID"].ToString();
            DataTable dt = new DataTable();
            dt = SQLHelper.FillData(strcmd);
            if(dt.Rows.Count>0)
            {
                for(int i=0;i<dt.Rows.Count;i++)
                {
                    string ProductID = dt.Rows[i]["ProductID"].ToString();
                    string Price= dt.Rows[i]["Price"].ToString();
                    string Qty = dt.Rows[i]["Qty"].ToString();
                    strcmd = "insert into OrderChild(id,ProductID,Price,Qty) values('" + id + "'," +
                        ProductID + "," + Price + "," + Qty + ")";
                    SQLHelper.ExecuteNonQuery(strcmd);
                }
                strcmd = "delete from Cart where UserID=" + Session["UserID"].ToString();
                SQLHelper.ExecuteNonQuery(strcmd);
                Response.Redirect("~/Status.aspx");
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int index = 0;
        if (e.CommandName == "Del")
        {
            index = Convert.ToInt32(e.CommandArgument);
            string strID = GridView1.Rows[index].Cells[0].Text;
            try
            {
                string strcmd = "delete from Cart where ProductID=" + strID;
                SQLHelper.ExecuteNonQuery(strcmd);
                lblMsg.Text = "successfully Remove";
                LoadCart();
            }
            catch (Exception ex)
            {
                lblMsg.Text = ex.Message;
            }
        }
    }

}
